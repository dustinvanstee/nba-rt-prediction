#!/bin/bash
scp bmcSearch.html   root@bdxcat2.pbm.ihost.com:/home/webdesign/
scp bmcSearch.js     root@bdxcat2.pbm.ihost.com:/home/webdesign/
scp bmcSearchInit.js root@bdxcat2.pbm.ihost.com:/home/webdesign/
 
