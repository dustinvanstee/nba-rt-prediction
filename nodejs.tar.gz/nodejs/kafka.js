/*jshint node:true*/

// This application uses express as it's web server
// for more info, see: http://expressjs.com
var express = require('express');

// cfenv provides access to your Cloud Foundry environment
// for more info, see: https://www.npmjs.com/package/cfenv

var cfenv = require('cfenv');
//var websiteTitle = require('./websitetitle');

// create a new express server
var app  = express();
var path = require("path");
var MessageHub = require('message-hub-rest');
// var services = process.env.VCAP_SERVICES;
var services = {
   "Object-Storage": [
      {
         "name": "Apache Spark-82_objectstore",
         "label": "Object-Storage",
         "plan": "Free",
         "credentials": {
            "auth_url": "https://identity.open.softlayer.com",
            "project": "object_storage_0dc58f04_2c63_4761_9aed_ef4449bae858",
            "projectId": "f4162fef734849528c38937ca26ba3a7",
            "region": "dallas",
            "userId": "e1bd346a6f524258842941f74be4352a",
            "username": "Admin_2cea3ee39a3cedda10e5a421a353e1a97a61187a",
            "password": "ue)Hm*}nTdN2AM2^",
            "domainId": "7527e49e459a4de4a41373a7e8fb444f",
            "domainName": "984499"
         }
      }
   ],
   "messagehub": [
      {
         "name": "NBA-RT-PREDICTION",
         "label": "messagehub",
         "plan": "standard",
         "credentials": {
            "api_key": "Ka2PDzteshNnqbz6WMr8IBCv6BldwluUSJJ95djogriM88ez",
            "kafka_admin_url": "https://kafka-admin-prod01.messagehub.services.us-south.bluemix.net:443",
            "kafka_rest_url": "https://kafka-rest-prod01.messagehub.services.us-south.bluemix.net:443",
            "kafka_brokers_sasl": [
               "kafka01-prod01.messagehub.services.us-south.bluemix.net:9093",
               "kafka02-prod01.messagehub.services.us-south.bluemix.net:9093",
               "kafka03-prod01.messagehub.services.us-south.bluemix.net:9093",
               "kafka04-prod01.messagehub.services.us-south.bluemix.net:9093",
               "kafka05-prod01.messagehub.services.us-south.bluemix.net:9093"
            ],
            "user": "Ka2PDzteshNnqbz6",
            "password": "WMr8IBCv6BldwluUSJJ95djogriM88ez"
         }
      }
   ]
}


//var services = require('services.json');
var instance = new MessageHub(services);
var consumerInstance;
var topicName = 'mytopic';



//http://expressjs.com/en/starter/static-files.html
app.use(express.static('public'));


app.get('/', function(req, res) {
  res.sendFile(path.join(__dirname+'/index.html'));
});
// app.get('/rtpjs', function(req, res) {
//   res.sendFile(path.join(__dirname+'/rtp.js'));
// });


app.get('/scoreprediction/:sd/:tl/:spr', function(req, res) {


  var intercept = 0.03437454446866164
  var weights   = [0.07777566101325575,0.0061780161634745045,-0.10528919257886181,0.09145774467717606]
  var sdt = parseFloat(req.params.sd) / Math.pow( (parseFloat(req.params.tl) / 8) + 0.1, 0.5)
  var e0X = Math.exp(intercept + weights[0]*parseFloat(req.params.sd)
                               + weights[1]*parseFloat(req.params.tl)
                               + weights[2]*parseFloat(req.params.spr)
                               + weights[3]*sdt
                              );
  var probability = 1 / (1 + e0X)

  var data = []

  data.push({
    e0X : e0X,
    probability : probability,
    sdt : sdt
  })
  res.json(data);
});

//app.get('/produce', function(req, res) {
//  res.sendFile(path.join(__dirname+'/index.html'));
//});


// get the app environment from Cloud Foundry
var appEnv = cfenv.getAppEnv();

// start server on the specified port and binding host
app.listen(appEnv.port, appEnv.bind, function() {

  // print a message when the server starts listening
  console.log("server starting on " + appEnv.url);
});


// KAFKA STUFF //



instance.topics.create(topicName)
  .then(function(response) {
      return instance.consume('my_consumer_group', 'my_consumer_instance', { 'auto.offset.reset': 'largest' });
  })
  .then(function(response) {
    consumerInstance = response[0];
  })
  .fail(function(error) {
    throw new Error(error);
  });

var receivedMessages = 0;
var produceInterval = setInterval(function() {

  var list = new MessageHub.MessageList([
    "This is the dustin's message text"
  ]);

  instance.produce('mytopic', list.messages)
    .then(function() {
      return consumerInstance.get('mytopic');
    })
    .then(function(data) {
      console.log('data = ' + data + ' rcvmsg = ' + receivedMessages);
      receivedMessages++;

      if(receivedMessages >= 3) {
        clearInterval(produceInterval);
        return consumerInstance.remove();
      }
    })
    .fail(function(error) {
      throw new Error(error);
    });

}, 1000);


