/*jshint node:true*/

// 051806 v1.0 DV Fixed missing negative sign in logistic issue

// This application uses express as it's web server
// for more info, see: http://expressjs.com
var express = require('express');
var path = require("path");
var MessageHub = require('message-hub-rest');
var morgan = require("morgan")

// cfenv provides access to your Cloud Foundry environment
// for more info, see: https://www.npmjs.com/package/cfenv
var cfenv = require('cfenv');
//var websiteTitle = require('./websitetitle');

// create a new express server
var app  = express();
var path = require("path");

//http://expressjs.com/en/starter/static-files.html
// Setup public directory ...
app.use(express.static('public'));
app.use(morgan('dev'))


app.get('/', function(req, res) {
  res.sendFile(path.join(__dirname+'/index.html'));
});

// V1 Score prediction endpoint (no error checking ...)
app.get('/scoreprediction/:sd/:tl/:spr', function(req, res) {

  var intercept = 0.03437454446866164
  var weights   = [0.07777566101325575,0.0061780161634745045,-0.10528919257886181,0.09145774467717606]
  var sdt = parseFloat(req.params.sd) / Math.pow( (parseFloat(req.params.tl) / 8) + 0.1, 0.5)
  var e0X = Math.exp(-1* (intercept + weights[0]*parseFloat(req.params.sd)
                               + weights[1]*parseFloat(req.params.tl)
                               + weights[2]*parseFloat(req.params.spr)
                               + weights[3]*sdt
                              ));
  var probability = 1 / (1 + e0X)

  var data = []

  data.push({
    e0X : e0X,
    probability : probability,
    sdt : sdt
  })
  res.json(data);
});

// V2 Score prediction endpoint (no error checking ...)
app.get('/scorepredictionv2/:scorea/:scoreh/:timeleft/:overunder/:spread', function(req, res) {

  // Feature calc's and shorthand vars
  scorea = parseFloat(req.params.scorea)
  scoreh = parseFloat(req.params.scoreh)
  timeleft = parseFloat(req.params.timeleft)
  teamaspread = parseFloat(req.params.spread)
  overunder = parseFloat(req.params.overunder)
  teama_vegas_fscore = parseFloat(req.params.overunder) / 2.0 - teamaspread / 2.0
  teamh_vegas_fscore = parseFloat(req.params.overunder) / 2.0 + teamaspread / 2.0
  teama_adj_fscore   = parseFloat(req.params.scorea) + ( parseFloat(req.params.timeleft) / 48.0 ) * teama_vegas_fscore;
  teamh_adj_fscore   = parseFloat(req.params.scoreh) + ( parseFloat(req.params.timeleft) / 48.0 ) * teamh_vegas_fscore;

  //console.log("scorea " + scorea);
  //console.log("scoreh " + scoreh);
  //console.log("teama_vegas_fscore " + teama_vegas_fscore);
  //console.log("teamh_vegas_fscore " + teamh_vegas_fscore);
  //console.log("teama_adj_fscore " + teama_adj_fscore);
  //console.log("teamh_adj_fscore " + teamh_adj_fscore);
  //console.log("teamaspread " + teamaspread);


  // Logistic Regression Model Calculation
  var sd = scoreh - scorea  // score_differential
  var log_intercept =  0.18105412017545947
  var log_weights   = [-0.022673484410389144,0.03712741867234266,0.24727013696720132,1.9811487903448178E-4,0.1409637792718528,-8.19728150908266E-5]
  var pctleft = (timeleft/48.0)*100

  var cf1 = sd / Math.pow( (pctleft / 25) + 0.01, 0.5)
  var cf2 = sd / Math.pow( (pctleft / 2) + 0.01, 1.3)
  var cf3 = pctleft * teamaspread / 100
  var cf4 = Math.pow( sd , 3)

  //console.log("sd  " + sd);
  //console.log("pctleft  " + pctleft);
  //console.log("cf1  " + cf1);
  //console.log("cf2  " + cf2);
  //console.log("cf3  " + cf3);
  //console.log("cf4  " + cf4);


  var e0X = Math.exp(-1* (log_intercept + log_weights[0] * sd
                                        + log_weights[1] * teamaspread
                                        + log_weights[2] * cf1
                                        + log_weights[3] * cf2
                                        + log_weights[4] * cf3
                                        + log_weights[5] * cf4
                                        ));
  var probability = 1 / (1 + e0X)


  // Away Team Linear Regression
  var lina_intercept = 19.176380293860646
  var lina_weights   = [-0.12584590287499697,0.16946300860166014,1.016763396436069,-0.04881112500588531,0.0595407362016495,-0.048076331109249526,-0.005053517122577144,-0.09152960467230607,-0.06064260292598313]
  // from spark analyis .setInputCols(Array("scorea", "scoreb", "teama_adj_fscore", "teamb_adj_fscore", "timeleft", "overunder", "teama_vegas_fscore", "teamb_vegas_fscore","teamaspread" ))

  var lina_score = lina_intercept +
                   lina_weights[0] * scorea +
                   lina_weights[1] * scoreh +
                   lina_weights[2] * teama_adj_fscore +
                   lina_weights[3] * teamh_adj_fscore +
                   lina_weights[4] * timeleft +
                   lina_weights[5] * overunder +
                   lina_weights[6] * teama_vegas_fscore +
                   lina_weights[7] * teamh_vegas_fscore +
                   lina_weights[8] * teamaspread ;
  // Linear Home
  var linh_intercept = 18.036862060680093
  var linh_weights   =  [0.12692292699277813,0.028671778928129152,-0.005560660186626133,0.8631932003132651,0.33447190640002666,-0.037514964466572126,-0.12590206857860975,0.01570042735671513,0.07286551381167104]
  var linh_score = linh_intercept +
                   linh_weights[0] * scorea +
                   linh_weights[1] * scoreh +
                   linh_weights[2] * teama_adj_fscore +
                   linh_weights[3] * teamh_adj_fscore +
                   linh_weights[4] * timeleft +
                   linh_weights[5] * overunder +
                   linh_weights[6] * teama_vegas_fscore +
                   linh_weights[7] * teamh_vegas_fscore +
                   linh_weights[8] * teamaspread ;

  //console.log("lina_score " + lina_score);
  //console.log("linh_score " + linh_score);


  var data = []

  data.push({
    e0X : e0X,
    probability : probability,
    linh_score : linh_score,
    lina_score : lina_score,
  })
  res.json(data);
});

// get the app environment from Cloud Foundry
var appEnv = cfenv.getAppEnv();

// start server on the specified port and binding host
app.listen(appEnv.port, appEnv.bind, function() {

	// print a message when the server starts listening
  console.log("server starting on " + appEnv.url);
});


