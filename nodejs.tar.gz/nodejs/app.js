/*jshint node:true*/

// This application uses express as it's web server
// for more info, see: http://expressjs.com
var express = require('express');
var path = require("path");
var MessageHub = require('message-hub-rest');
var morgan = require("morgan")

// cfenv provides access to your Cloud Foundry environment
// for more info, see: https://www.npmjs.com/package/cfenv

var cfenv = require('cfenv');
//var websiteTitle = require('./websitetitle');

// create a new express server
var app  = express();
var path = require("path");

//http://expressjs.com/en/starter/static-files.html
// Setup public directory ...
app.use(express.static('public'));
app.use(morgan('dev'))

var fs = require("fs");
var servicecontent = fs.readFileSync("private/services.json");
var services = JSON.parse(servicecontent);
// var services = process.env.VCAP_SERVICES;

console.log("Output services : \n"+ JSON.stringify(services,null,2));


app.get('/', function(req, res) {
  res.sendFile(path.join(__dirname+'/index.html'));
});
// app.get('/rtpjs', function(req, res) {
//   res.sendFile(path.join(__dirname+'/rtp.js'));
// });


app.get('/scoreprediction/:sd/:tl/:spr', function(req, res) {


  var intercept = 0.03437454446866164
  var weights   = [0.07777566101325575,0.0061780161634745045,-0.10528919257886181,0.09145774467717606]
  var sdt = parseFloat(req.params.sd) / Math.pow( (parseFloat(req.params.tl) / 8) + 0.1, 0.5)
  var e0X = Math.exp(intercept + weights[0]*parseFloat(req.params.sd)
                               + weights[1]*parseFloat(req.params.tl)
                               + weights[2]*parseFloat(req.params.spr)
                               + weights[3]*sdt
                              );
  var probability = 1 / (1 + e0X)

  var data = []

  data.push({
    e0X : e0X,
    probability : probability,
    sdt : sdt
  })
  res.json(data);
});

app.get('/scorepost/:sd/:tl/:spr', function(req, res) {
  // this is where I will post a message to a kafka topic
  var instance = new MessageHub(services);
  var consumerInstance;
  var topicName = 'nba-rtp';

  data = { "sd"  : req.params.sd,
           "tl"  : req.params.tl,
           "spr" : req.params.spr}

  var list = new MessageHub.MessageList([
    JSON.stringify(data)
  ]);
  console.log(JSON.stringify(list))
  console.log(list.messages)

  //var kafka_result = instance.produce(topicName, list.messages)
  //.then(function(){
  //  console.log("still not Done!")
  //  return instance.consume('my_binary_consumer', 'my_binary_instance', { 'auto.offset.reset': 'smallest' });
  //})


  instance.consume('my_binary_consumer', 'my_binary_instance', { 'auto.offset.reset': 'largest' })
  .then(function(response) {
    console.log("assign consumer instance")
    console.log("response = " + response[0])
    consumerInstance = response[0];
  })
  .then(function() {
      console.log("####### getting topic 1" + topicName)
      return consumerInstance.get(topicName);
  })
  .then(function(request) {
      console.log(" ####### Producing a topic message on ." + topicName)
      instance.produce(topicName, list.messages)
  })
  .then(function() {
      console.log("####### getting topic 2" + topicName)
      return consumerInstance.get(topicName);
  })
  .then(function(data) {
      console.log('####### data = ' + data);
      consumerInstance.remove();
      return data
  })
  .fail(function(error) {
    console.log("error")
    throw new Error(error);
  });




});





// get the app environment from Cloud Foundry
var appEnv = cfenv.getAppEnv();

// start server on the specified port and binding host
app.listen(appEnv.port, appEnv.bind, function() {

	// print a message when the server starts listening
  console.log("server starting on " + appEnv.url);
});




/////// OLD CODE ///////////////////////



//app.get('/quote/random', function(req, res) {
//  var id = Math.floor(Math.random() * quotes.length);
//  var q = quotes[id];
//  res.json(q);
//});

//app.get('/quote/:id/:id2', function(req, res) {
//  if(quotes.length <= req.params.id || req.params.id < 0) {
///    res.statusCode = 404;
//   return res.send('Error 404: No quote found');
//  }
//  var q = [quotes[req.params.id], quotes[req.params.id2]];

//  res.json(q);
//});

  //
  //if(quotes.length <= req.params.id || req.params.id < 0) {
  //  res.statusCode = 404;
  //  return res.send('Error 404: No quote found');
  //}
  //var rv1 = Math.floor(Math.random(78) + req.params.f1);
  //var rv2 = Math.floor(Math.random() - req.params.f2);
  //var rv2 = Math.exp(parseInt(req.params.f1) + parseInt(req.params.f2));

  // serve the files out of ./public as our main files
//app.set('view engine', 'jade');

//app.get('/text', function (req, res) {
//  res.type('text/plain');
//  res.send('home test');
//});

//app.get('/', function(req, res) {
//  res.json(quotes);
//});
 //var q = [quotes[req.params.id], quotes[req.params.id2]];
  //data.push({
  //  key : "probability",
  //  value : probability
  //})  //var q = [quotes[req.params.id], quotes[req.params.id2]];


//var quotes = [
//  { author : 'Audrey Hepburn', text : "Nothing is impossible, the word itself says 'I'm possible'!"},
//  { author : 'Walt Disney', text : "You may not realize it when it happens, but a kick in the teeth may be the best thing in the world for you"},
//  { author : 'Unknown', text : "Even the greatest was once a beginner. Don't be afraid to take that first step."},
//  { author : 'Neale Donald Walsch', text : "You are afraid to die, and you're afraid to live. What a way to exist."}
//];


