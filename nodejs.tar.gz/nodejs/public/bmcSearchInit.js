// TODO : Hyperlink bmid to netdb for now ...

$(document).ready(function(){

  //$('[data-toggle="popover"]').popover();
  $("#about").popover({ trigger: "hover" });
    $("#searchId").popover({ trigger: "hover" });

  //$("#searchId").popover({ placement : 'left'});
});