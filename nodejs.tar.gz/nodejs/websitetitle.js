var title = "Lauren's Lovely Landscapes";

var websiteTitle = {

  setTitle : function(newTitle) {
    title = newTitle;
  },
  getTitle : function() {
    return title;
  }

}

module.exports = websiteTitle;