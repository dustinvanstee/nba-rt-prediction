// 051806 v1.0 DV Fixed missing negative sign in logistic issue

$( document ).ready(function() {
  console.log("ready");


  $('#staticLabel0').width(300)

  // Home / Away drop down code here -- This took a while....
 $('.dropdown-select').on( 'click', '.dropdown-menu li', function() {
     var target = $(this).html();

     //Adds active class to selected item
     $(this).parents('.dropdown-menu').find('li').removeClass('active');
     $(this).parent('li').addClass('active');

     //Displays selected text on dropdown-toggle button
     $(this).parents('.dropdown-select').find('.dropdown-toggle').html(target + ' <span class="caret"></span>');
     console.log($(this).text)
  });

  $('#goButton').on('click', function() {
    getProbabilityWrapper()
  });


  // Example slider interactions code
  //$("#homeSlider").click(function() { $(this).remove();});import org.apache.spark.sql._


  $("#homeSlider").slider({
    tooltip: 'show'
  });

  $('.Slider').on('change', function(slideEvt) {
      console.log("New Value =" + slideEvt.value);
      getProbabilityWrapper()

  });

 $('#spreadSlider').on('change', function() {
    var teambspread = $('#spreadSlider').slider('getValue');
    var teamh = $('#homeTeamDropDown').text();
    var teama = $('#awayTeamDropDown').text();
    var hintText =  teama + " favor by " + teambspread

    if(teambspread < 0 ) {
      spreadString = teambspread * -1
      hintText =  teamh + " favor by " + spreadString
    }
    $('#spreadHint').text(hintText)

  });


  // Example morris line graph
  dchart = Morris.Donut({
    // ID of the element in which to draw the chart.
    element: 'mydonutchart',
    data: [
      { label: 'a', value: 0.5 },
      { label: 'b', value: 0.5 }
    ],
    colors : ['#428bca', '#5bc0de'],
    resize: ['true']
  });


  bchart = Morris.Bar({
    element: 'mybarchart',
    data: [
      { y: 'home',   c: 50, pd: 90 },
      { y: 'away',   c: 50, pd: 75 },
    ],
    xkey: 'y',
    ykeys: ['c', 'pd'],
    labels: ['cur', 'proj'],
    //axes : 'true'
    stacked : 'true'
  });


   getProbabilityWrapper()
  $('#mybarchart').show()
  $('#mydonutchart').show()
  $('#resultbox0').show()
  $('#resultbox1').show()
  $('#predictedHomeScore').show()
  $('#predictedAwayScore').show()

});

// Wrapper function that gets slider vals, and calls
// the getProbability function
function getProbabilityWrapper() {
    var scoreh = $('#homeScoreSlider').slider('getValue');
    var scorea = $('#awayScoreSlider').slider('getValue');
    var timeleft = $('#timeLeftSlider').slider('getValue');
    var teambspread = $('#spreadSlider').slider('getValue');
    var teamaspread = teambspread * -1
    var overunder = 219;  // Hardcoded b/c this was not really and indicator
    var teama = $('#awayTeamDropDown').text();
    var teamh = $('#homeTeamDropDown').text();

    //console.log("slider val = " + value)

    var prob = getProbability(scorea,scoreh,timeleft,overunder,teamaspread,teama,teamh);
    console.log("Prob = " + prob)
}


function getProbabilityWrapper1() {
    var scoreh = 62
    var scorea = 73
    var timeleft = 15.76
    var teamaspread = 5.5
    var overunder = 219;  // Hardcoded b/c this was not really and indicator
    var teama = "sac"
    var teamh = "pho"

    //console.log("slider val = " + value)

    var prob = getProbability(scorea,scoreh,timeleft,overunder,teamaspread,teama,teamh);
    console.log("Prob = " + prob)
}



/////////////////////////////////////////////////////
// This function just queries the probabilty and score service and
// returns the probability, and final score predictions between 0 - 100
// It then call updateChart to render results on the screen
function getProbability(scorea,scoreh,timeleft,overunder,teamaspread,teama,teamh) {

  var prob = 0.0
  //app.get('/scorepredictionv2/:scorea/:scoreh/:timeleft/:overunder/:teamaspread',

  console.log('http://localhost:6001/scorepredictionv2/' + scorea + '/' + scoreh + '/' + timeleft + '/' + overunder + '/' + teamaspread)

  var mytestquery = jQuery.ajax({
     //url: 'http://localhost:6001/scorepredictionv2/' + scorea + '/' + scoreh + '/' + timeleft + '/' + overunder + '/' + teamaspread  ,
     url: 'http://169.55.24.28:6001/scorepredictionv2/' + scorea + '/' + scoreh + '/' + timeleft + '/' + overunder + '/' + teamaspread  ,
    success: function (data){
        //console.log("output =" + $.data)
        console.log("data = "+ JSON.stringify(data));
        //console.log("data = "+ JSON.stringify(data.response, undefined,2 ));
        //$('#table_to_mod table > tbody:first').find('tr:first').before(data.response.docs[1]);
        //var newjson = JSON.parse(data.result)

        console.log("Number of hits returned = "+ data.length);

        for (var i = 0; i < data.length; i++) {

          var teamw = teamh
          var teaml = teama
          if(parseFloat( data[i].probability) < 0.5) {
            teamw = teama
            teaml = teamh
            data[i].probability = 1 - parseFloat( data[i].probability)
          }


          console.log(" team = " + teamw + " prob = " + data[i].probability);
          console.log(" team = " + teamw + " lina = " + data[i].lina_score);
          console.log(" team = " + teamw+ " linh = " + data[i].linh_score);


          updateChart(teamw,teaml,data[i].probability,data[i].linh_score,data[i].lina_score);

       }

      },
      error: function (data) {
         console.log("Error")
      }
   });

  return 0;
}



function updateChart (teamw,teaml,prob,pscoreh,pscorea) {
  var probn = ((1 - prob)*100).toString().substring(0,4)
  prob = (prob *100).toString().substring(0,4)

  dchart.setData([
    { label: teamw, value: prob },
    { label: teaml, value: probn }
  ]);
  var teama = $('#awayTeamDropDown').text().replace(/\s+/g, '');
  var teamh = $('#homeTeamDropDown').text().replace(/\s+/g, '');
  var scoreh = $('#homeScoreSlider').slider('getValue');
  var scorea = $('#awayScoreSlider').slider('getValue');

  console.log(scorea)
  console.log(scoreh)
  console.log(pscorea)
  console.log(pscoreh)


  var pdscoreh = pscoreh - scoreh;
  var pdscorea = pscorea - scorea;

  bchart.setData([
    { y: teamh,   c: scoreh,  pd: pdscoreh },
    { y: teama,   c: scorea,  pd: pdscorea }
  ]);

  var scoreHomeString =  "<h4>" + sprintf("%-15s", teamh) + "\t" + pscoreh.toString().substring(0,5) + "</h4>" ;
  var scoreAwayString =  "<h4>" + sprintf("%-15s", teama) + "\t" + pscorea.toString().substring(0,5) + "</h4>" ;
  // console.log(scoreString)
  $('#predictedHomeScore').html(scoreHomeString);
  $('#predictedAwayScore').html(scoreAwayString);



  $('#mybarchart').show()
  $('#mydonutchart').show()
  $('#resultbox0').show()
  $('#resultbox1').show()
  $('#predictedHomeScore').show()
  $('#predictedAwayScore').show()
}

